from django.apps import AppConfig


class detalhesprodutoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'detalhesproduto'
