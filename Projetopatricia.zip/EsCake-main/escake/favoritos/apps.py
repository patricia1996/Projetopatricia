from django.apps import AppConfig


class FavoritosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'favoritos'
